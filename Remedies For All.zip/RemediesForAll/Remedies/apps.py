from django.apps import AppConfig


class PythonConfig(AppConfig):
    name = 'Remedies'
