from django.db import models

class Clients(models.Model):
    Cid = models.CharField(max_length=20)
    Cname = models.CharField(max_length=100)
    Cemail = models.EmailField()
    Ccontact = models.CharField(max_length=15)

class Meta:
    db_table = "client"