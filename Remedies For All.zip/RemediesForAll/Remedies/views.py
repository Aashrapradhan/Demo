from django.shortcuts import render, redirect
from Remedies.forms import ClientsForm
from Remedies.models import Clients

def home(request):
    return render(request, '')

def cli(request):
    if request.method == "POST":
        form = ClientsForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect()
            except:
                pass
        else:
             form = ClientsForm()
        return render(request, "index.html", {'form':form})

def show(request):
    clients = Clients.objects.all()
    return render(request,"show.html",{'clients': clients})

def edit(request, id):
    clients = Clients.objects.get(id=id)
    return render(request,"edit.html",{'clients' : clients})

def update(request, id):
  clients = Clients.objects.get(id=id)
  form = ClientsForm(request.POST, instance= clients)
  if form.is_valid():
      form.save()
      return redirect('/show')
  return render(request,"edit.html",{'clients': clients})

def delete(request, id):
    clients = ClientsForm.objects.get(id=id)
    clients.delete()
    return redirect("/show")





